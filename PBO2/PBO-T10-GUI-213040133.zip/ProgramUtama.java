package PBO2;

public class ProgramUtama {
	public static void main(String[] args) {
//		new HelloWorldForm1();
		new HelloWorldForm2();
//		new HelloWorldForm3();
	}
}
